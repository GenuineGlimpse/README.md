Web Development (Introduction) ST10480969 POE Part 1/
├── README.md <- copy here also
├── Chosen Proposal/
├── Proposals/
├── Research/
└── Website/
├── README.md <- MAIN ONE FOR GITHUB
├── Index.html
├── About.html
├── Services.html
├── Enquiry.html
├── Contact Us.html
├── CSS/style.css
├── JavaScript/script.js
└── images/ (your 9 project photos)
