// Helix 360 Construction - Part 1 JS (Part 3 will add validation)
console.log("Helix 360 Construction Projects website loaded");

// Simple form alert for Part 1 - Part 3 will add full JS validation
document.addEventListener('DOMContentLoaded', function() {
const forms = document.querySelectorAll('form');
forms.forEach(form => {
form.addEventListener('submit', function(e) {
e.preventDefault();
alert("Thank you for contacting Helix 360! We will call you on 082 545 0881 soon. (JS validation will be added in Part 3)");
});
});
});